
// Scan I2C bus for device responses


#define I2C_TIMEOUT 0
#define I2C_NOINTERRUPT 0
#define I2C_FASTMODE 0
#define FAC 1
#define I2C_CPUFREQ (F_CPU/FAC)

/* Corresponds to A4/A5 - the hardware I2C pins on Arduinos */
/* Adjust to your own liking */
#define SDA_PORT PORTC
#define SDA_PIN 4
#define SCL_PORT PORTC
#define SCL_PIN 5
#define I2C_FASTMODE 0


#include "SoftI2CMaster.h"
#include <avr/io.h>
#include <stdlib.h>
#include <avr/pgmspace.h>

//------------------------------------------------------------------------------
void CPUSlowDown(int fac) {
  // slow down processor by a fac
    CLKPR = _BV(CLKPCE);
    CLKPR = _BV(CLKPS1) | _BV(CLKPS0);
}
  


void i2c_setup(void) {
#if FAC != 1
  CPUSlowDown(FAC);
#endif


  if (!i2c_init()) 
    puts_P(PSTR("Initialization error. SDA or SCL are low"));
  else
    puts_P(PSTR("...done"));
}


void i2c_scan(void)
{
  uint8_t add = 0;
  char buffer[7];

  int found = false;
  puts_P(PSTR("Scanning ..."));

  puts_P(PSTR("       8-bit 7-bit addr"));
  // try read
  do {
    delay(100);
    if (i2c_start(add | I2C_READ)) {
      found = true;
      i2c_read(true);
      i2c_stop();
  
      puts_P(PSTR("Read:   0x"));
      if(add<0x0F) puts_P(PSTR("0"));
      itoa(add+I2C_READ, buffer, 16);
      puts(buffer);

      puts_P(PSTR("  0x"));
      if (add>>1 < 0x0F) puts_P(PSTR("0"));
      itoa(add>>1, buffer, 16);
      puts(buffer);
      
    } else i2c_stop();
    add += 2;
  } while (add);

  // try write
  add = 0;
  do {
    if (i2c_start(add | I2C_WRITE)) {
      found = true;
      i2c_stop();

      puts_P(PSTR("Write:  0x"));    
      if (add < 0x0F) puts_P(PSTR("0"));  
      itoa(add+I2C_WRITE, buffer,16);
      puts(buffer);

      puts_P(PSTR("  0x"));
      if (add>>1 < 0x0F) puts_P(PSTR("0"));
      itoa(add>>1, buffer, 16);
    
  } else i2c_stop();
    i2c_stop();
    add += 2;
  } while (add);
  if (!found) puts_P(PSTR("No I2C device found."));
  puts_P(PSTR("Done\n\n"));

  //delay(1000/FAC);
}

int main(){

  i2c_setup();
  i2c_scan();
  return 1;
}
